# Atelier design system

This package defines the visual language AND the default page layout for the
project. Use it whenever you build or restyle UI so every surface looks like
the same product. It is a real package (`@cognirise/atelier`): the app depends
on it and imports its theme, layout and components directly.

Two documents are contracts, not suggestions:

- `docs/LAYOUT.md` — the default page layout every app is built on.
- `docs/ARCHETYPES.md` — the standard menu of a prototype: what each screen
  answers and what must appear on it.
- `docs/REBRANDING.md` — the only four things a client rebrand may change
  (logo assets, color tokens, the brand block, the two backdrops).

Read both before building UI or changing a theme.

## What's here

- `tokens.json` — the single source of truth (DTCG format): colors (full light
  and dark sets), the `brand` block (accent gradient, status hues, backdrop
  gradient stops, backdrop artwork, the hero dark island), typography, spacing,
  and radius. A client rebrand edits THIS FILE and `public/brand/` — nothing
  else. Every value the brand layer needs is here, so no component or
  stylesheet should ever carry a literal brand color again.
- `scripts/build-tokens.mjs` — generates the outputs below from `tokens.json`.
- `src/index.css` — GENERATED token theme (web), exported as `./styles.css`.
- `src/generated/tokens.tsx` — GENERATED hex token object, the package's `.` and
  `./tokens` entry. Mobile (Expo) and other platforms import this.
- `public/favicon.svg` — App icon. Generated from `tokens.json` + title by
  `build-tokens.mjs`, then immediately overwritten with `public/brand/favicon.svg`
  (falling back to the committed Cognirise favicon) if that file exists, so the
  real brand icon survives every token build.
- `src/components/layout/` — THE DEFAULT PAGE LAYOUT, exported as `./layout`:
  `AppShell`, `AppBackdrop`, `TitleBar`, `ContextNav`, `LensPicker`,
  `ThemeModeToggle`, `ThemeProvider`/`themeInitScript`, `PageHero`,
  `PageContainer`, `PageSection`, `ChatRail`, `ChatComposer`, and the brand
  logo/wordmark components. Apps compose these; they do not rebuild the frame.
  See `docs/LAYOUT.md`.
- `public/brand/` — the client-swappable assets at fixed paths
  (`logo-on-dark.png`, `logo-on-light.png`, `mark.png`, `favicon.svg`,
  `light-backdrop.webp`, `dark-backdrop.webp`). No component names a client.
- `src/components/ui/` — the shadcn component library, exported as
  `./components/*`. Generated systems keep and theme it; Figma imports prune and
  restyle it; code imports replace it with the source component library.
- `src/lib/` (`cn`) and `src/hooks/` — exported as `./lib/*` and `./hooks/*`.
- `src/App.tsx` — the entry point for the living style guide.
- `src/preview/DesignSystemBrowser.tsx` — the persistent grouped navigation,
  branded header, search, deep links, and active page shell.
- `src/preview/registry.tsx` — preview metadata (`DESIGN_SYSTEM` title,
  description) and ordered navigation. Overview comes first;
  Brand/Colors/Fonts/Layout precede Components; Content/Charts/Motion/Applied
  examples follow when applicable. Each group is a nav section whose entries
  are its nested pages. Empty optional groups stay hidden. Keep component pages
  loaded with `lazy(() => import(...))` so opening the preview does not download
  every story.
- `src/preview/foundations.tsx` — token-driven Overview, Colors, Fonts, and Layout
  pages.
- `src/preview/parts.tsx` — shared page helpers, including `Guidelines` for design
  and composition do's/don'ts (colour/component usage, hierarchy, voice and tone,
  not technical implementation notes). Populate it only with guidance derived
  from the source; omit it when the source documents no usage rules.
- `src/preview/demos/<component>.tsx` — component stories. Keep these stories and
  the registry aligned with the final web component inventory.
- `docs/references/` — retained Cognirise brand assets (logos, marks, favicon,
  backdrop wallpapers, OG image, Riser avatar) with usage + backdrop-layering
  notes in `docs/references/README.md`, and the source component inventory in
  `docs/references/component-inventory.md`. `scripts/theme-template.css` ends
  with the "Cognirise Atelier brand layer": the `--cog-grad` accent gradient,
  knob-driven glass surfaces (`.glass-card`/`.glass-panel`/`.glass-popover`,
  with reduced-transparency fallbacks), the `.cog-backdrop` fixed backdrop
  pattern, the `.page-hero` navy dark-island, and editorial primitives
  (`.eyebrow`, `.section-divider`, `.section-label`, `.lede`, `.pill-btn`,
  `.mono-chip`, `.accent-pill`, `.tab-nav`). `Card` is customized to the glass
  surface. `pnpm tokens` regenerates `public/favicon.svg` but automatically
  overwrites it with the committed brand favicon so the real icon survives.
- `docs/consuming-web.md` and `docs/consuming-expo.md` — platform-specific usage.
- `docs/migrating-web.md` and `docs/migrating-expo.md` — replacing scaffolded or
  existing local design-system implementations.

Every source file in this package is a `.tsx` file, including token, utility,
and hook modules with no JSX, so every export below is a single `*.tsx` glob. Do
not add `.ts` files here.

## What this package exports

```jsonc
".":              "./src/generated/tokens.tsx",
"./tokens":       "./src/generated/tokens.tsx",
"./styles.css":   "./src/index.css",
"./layout":       "./src/components/layout/index.tsx",
"./components/*": "./src/components/*.tsx",
"./lib/*":        "./src/lib/*.tsx",
"./hooks/*":      "./src/hooks/*.tsx"
```

Components import each other with relative paths internally, so they resolve
correctly when another package imports them through
`@cognirise/atelier/components/...`. Never use a `@/` alias inside
this package. Components added through shadcn may use this package's
`#components/*`, `#lib/*`, and `#hooks/*` imports from `package.json`; those are
consumer-safe because they resolve against this package.

## Editing and maintaining the design system

Edit `tokens.json` only, then run `pnpm tokens`; the dev server also regenerates
on change. Never hand-edit `src/index.css` or `src/generated/tokens.tsx`.

Every user-facing web component under `src/components/ui/` must have a family
story in `src/preview/demos/` covering its variants, sizes, and important states.
Register each family once in `src/preview/registry.tsx`. If a component changes,
update its story and registry entry in the same change and note meaningful
additions or customizations in "What's here" above. Register new component pages
with dynamic imports; do not eagerly import stories into the registry.

Native components live under `src/components/native/`. Match an existing web
component family's public API wherever React Native supports it, and document
platform-required differences in "What's here". Native components are not
imported into the web-only Vite preview.

Keep `DESIGN_SYSTEM.title` and `DESIGN_SYSTEM.description` accurate. Update
`NAV_GROUPS` whenever the system gains or loses a foundation, content guideline,
chart, motion rule, or applied example.

## Keep it template-ready

This design system is a prime candidate to be saved to the workspace as a
reusable template, and a template is packaged as this one directory alone. Keep
it self-contained as you maintain it so that save works: use concrete dependency
versions (never `catalog:`), keep `tsconfig.json` standalone (never `extends` a
workspace-relative base), and never import from a sibling artifact or a shared
`@workspace/*` lib. A saved template is consumed as a read-only style donor
(re-authored from, not rebuilt), so keep the generated `src/index.css` and
`src/generated/tokens.tsx` committed so the template carries a readable theme
snapshot. If maintenance ever introduces a cross-artifact or workspace-lib
dependency, load the `prepare-artifact-template` skill and follow it to pull the
dependency back in before the user saves the template.

## Prototyping on the canvas

Use the mockup-sandbox skill's "Design systems" flow. It creates a sandbox entry
for `@cognirise/atelier` and renders mockups using this package's
theme and components.

## Consuming this package

Never copy token values, component source, hooks, or these docs into a consuming
artifact. Add `@cognirise/atelier` as a `workspace:*` dependency,
run `pnpm install`, and import directly from this package.

Read only the guides required by the current task:

- Building or styling web UI: `docs/consuming-web.md`
- Building or styling Expo UI: `docs/consuming-expo.md`
- Replacing an existing or scaffolded web theme/component library:
  `docs/migrating-web.md`
- Replacing existing or scaffolded Expo theme/hooks/components:
  `docs/migrating-expo.md`

A freshly scaffolded app counts as a migration when it still contains local
theme, hook, or component copies that this package supersedes. Read the platform
consumption guide first, then its migration guide before authoring UI.

For web/static consumers, follow the workspace dependency placement rules from
the pnpm-workspace skill. Expo is a runtime consumer, so the package belongs in
`dependencies`.

Before migrating an entire app, render one platform-appropriate primitive from
the package and run the consumer's typecheck and dev server. Proceed only after
the import resolves and the primitive uses this design system's theme.

## Universal rules

- Match exact token values. Do not invent colors, fonts, spacing, or radii in a
  consuming app.
- Keep product data, navigation, application state, and product-specific
  compositions in the app. Product-agnostic visual primitives belong here.
- Read these docs in place. Do not copy them into another artifact.
